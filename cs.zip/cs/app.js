const express = require("express");
const path = require('path');
const mysql = require("mysql");
const dotenv = require('dotenv');
const cookieParser = require('cookie-parser');

dotenv.config({path: './.env'});

const app = express();

const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'pom'
});

const publicDirectory = path.join(__dirname, './public');
app.use(express.static(publicDirectory));

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded({ extended: false }));
// Parse JSON bodies (as sent by API clients)
app.use(express.json());
app.use(cookieParser());

app.set('view engine', 'hbs');

conn.connect( (error) => {
    if(error) {
        console.log(error)
    } else {
        console.log("Happy Access!")
    }
})


// ================== C R U D ==== A D M I N  ================== //

// ========  A L A T ======== //

//route for homepage alat
app.get('/alat', (req, res) => {
    let sql = "SELECT * FROM alat";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.render('alat', {
        results: results
      });
    });
  });
  
  //route for insert data alat
  app.post('/save_alat', (req, res) => {
    let data = {
      Id_Alat: req.body.Id_Alat,
      lapisan_cat: req.body.lapisan_cat,
      alat_tangki: req.body.alat_tangki,
      alat_mesin: req.body.alat_mesin,
      bahan_instalasi: req.body.bahan_instalasi,
      spesifikasi_mesin: req.body.spesifikasi_mesin
    };
    let sql = "INSERT INTO alat set ?";
    let query = conn.query(sql, data, (err, results) => {
      if (err) throw err;
      res.redirect('/alat');
    });
  });
  
  //route for update data alat
  app.post('/update_alat', (req, res) => {
    let sql = "UPDATE alat SET lapisan_cat='" + req.body.lapisan_cat + "', alat_tangki='" + req.body.alat_tangki + "', alat_mesin='" + req.body.alat_mesin + "', bahan_instalasi='" + req.body.bahan_instalasi + "', spesifikasi_mesin='" + req.body.spesifikasi_mesin + "' WHERE Id_Alat=" + req.body.Id_Alat + "";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.redirect('/alat');
    });
  });
  
  //route for delete data alat
  app.post('/delete_alat', (req, res) => {
    let sql = "DELETE FROM alat WHERE Id_Alat=" + req.body.Id_Alat + "";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.redirect('/alat');
    });
  });
  

// ========  P R O D U K ===== P O M ======== //


//route for homepage produk
app.get('/produk', (req, res) => {
    let sql = "SELECT * FROM produk_pom";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.render('produk', {
        results: results
      });
    });
  });
  
  //route for insert data produk
  app.post('/save_produk', (req, res) => {
    let data = {
      Id_POM: req.body.Id_POM,
      jenis_pom: req.body.jenis_pom,
      harga: req.body.harga,
      kapasitas_tangki: req.body.kapasitas_tangki,
      tinggi: req.body.tinggi,
      lebar: req.body.lebar,
      panjang: req.body.panjang,
      tebal: req.body.tebal,
      plat: req.body.plat,
      bahan_body: req.body.bahan_body
    };
    let sql = "INSERT INTO produk_pom set ?";
    let query = conn.query(sql, data, (err, results) => {
      if (err) throw err;
      res.redirect('/produk');
    });
  });
  
  //route for update data produk
  app.post('/update_produk', (req, res) => {
    let sql = "UPDATE produk_pom SET 	jenis_pom='" + req.body.jenis_pom + "', harga='" + req.body.harga + "', kapasitas_tangki='" + req.body.kapasitas_tangki + "', tinggi='" + req.body.tinggi + "', lebar='" + req.body.lebar + "', panjang='" + req.body.panjang + "', tebal='" + req.body.tebal + "', plat='" + req.body.plat + "', bahan_body='" + req.body.bahan_body + "' WHERE Id_POM=" + req.body.Id_POM + "";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.redirect('/produk');
    });
  });
  
  //route for delete data produk
  app.post('/delete_produk', (req, res) => {
    let sql = "DELETE FROM produk_pom WHERE Id_POM=" + req.body.Id_POM + "";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.redirect('/produk');
    });
  });

// ========  U S E R ======== //

//route for homepage user
app.get('/user', (req, res) => {
    let sql = "SELECT * FROM users";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.render('user', {
        results: results
      });
    });
  });
  
  //route for insert data user
  app.post('/save_user', (req, res) => {
    let data = {
      id: req.body.id,
      name: req.body.name,
      email: req.body.email,
      password: req.body.password
  
    };
    let sql = "INSERT INTO users set ?";
    let query = conn.query(sql, data, (err, results) => {
      if (err) throw err;
      res.redirect('/user');
    });
  });
  
  //route for update data user
  app.post('/update_user', (req, res) => {
    let sql = "UPDATE users SET name='" + req.body.name + "', email='" + req.body.email + "'  password='" + req.body.password + "' WHERE id=" + req.body.id;
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.redirect('/user');
    });
  });
  
  //route for delete data user
  app.post('/delete_user', (req, res) => {
    let sql = "DELETE FROM users WHERE id=" + req.body.id + "";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.redirect('/user');
    });
  });

  // ========  A D M I N ======== //
  //route for homepage admin
app.get('/admin', (req, res) => {
  let sql = "SELECT * FROM costumer";
  let query = conn.query(sql, (err, results) => {
    if (err) throw err;
    res.render('admin', {
      results: results
    });
  });
});

//route for insert data admin
  app.post('/save_costumer', (req, res) => {
    let data = {
      id_costumer: req.body.id_costumer,
      tgl: req.body.tgl,
      nama: req.body.nama,
      alamat: req.body.alamat,
      no_hp: req.body.no_hp,
      id_pom: req.body.id_pom
    };
    let sql = "INSERT INTO costumer set ?";
    let query = conn.query(sql, data, (err, results) => {
      if (err) throw err;
      res.redirect('/admin');
    });
  });
  
  //route for update data aadmin
  app.post('/update_costumer', (req, res) => {
    let sql = "UPDATE costumer SET tgl='" + req.body.tgl + "', nama='" + req.body.nama + "', alamat='" + req.body.alamat + "', no_hp='" + req.body.no_hp + "', id_pom='" + req.body.id_pom + "' WHERE id_costumer=" + req.body.id_costumer + "";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.redirect('/admin');
    });
  });
  
  //route for delete data admin
  app.post('/delete_costumer', (req, res) => {
    let sql = "DELETE FROM costumer WHERE id_costumer=" + req.body.id_costumer + "";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.redirect('/admin');
    });
  });
  
  // ============ P R O F I L E ==================== //
  app.get('/profile', (req, res) => {
    let sql = "SELECT * FROM users";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.render('profile', {
        results: results
      });
    });
  });

// ================== LAYANAN CUSTOMER  ================== //
  
// ================== NAVBAR POM 1  ================== //

//route for homepage user
app.get('/pom1', (req, res) => {
    let sql = "SELECT * FROM produk_pom JOIN alat ON produk_pom.Id_Alat = alat.Id_Alat where Id_POM = '1' ";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.render('pom1', {
        results: results
      });
    });
  });
  
  // ================== NAVBAR POM 2  ================== //
  
  //route for homepage user
  app.get('/pom2', (req, res) => {
    let sql = "SELECT * FROM produk_pom JOIN alat ON produk_pom.Id_Alat = alat.Id_Alat where Id_POM='2'";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.render('pom2', {
        results: results
      });
    });
  });
  
  // ================== NAVBAR POM 3  ================== //
  
  //route for homepage user
  app.get('/pom3', (req, res) => {
    let sql = "SELECT * FROM produk_pom JOIN alat ON produk_pom.Id_Alat = alat.Id_Alat where Id_POM='3'";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.render('pom3', {
        results: results
      });
    });
  });
  
  // C H E C K O U T  1//
  //route for homepage user
  app.get('/checkout1', (req, res) => {
    let sql = "SELECT * FROM produk_pom where Id_POM='1'";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.render('checkout1', {
        results: results
      });
    });
  });

  //route for insert data alat
  app.post('/save_costumer', (req, res) => {
    let data = {
      id_costumer: req.body.id_costumer,
      tgl: req.body.tgl,
      Nama: req.body.Nama,
      Alamat: req.body.Alamat,
      no_hp: req.body.no_hp,
      Id_POM: req.body.Id_POM
    };
    let sql = "INSERT INTO costumer set ?";
    let query = conn.query(sql, data, (err, results) => {
      if (err) throw err;
      res.redirect('/invoice');
      
    });
  });
  
  // C H E C K O U T  2//
  //route for homepage user
  app.get('/checkout2', (req, res) => {
    let sql = "SELECT * FROM produk_pom where Id_POM='2'";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.render('checkout2', {
        results: results
      });
    });
  });
  
  // C H E C K O U T  3//
  //route for homepage user
  app.get('/checkout3', (req, res) => {
    let sql = "SELECT * FROM produk_pom where Id_POM='3'";
    let query = conn.query(sql, (err, results) => {
      if (err) throw err;
      res.render('checkout3', {
        results: results
      });
    });
  });
  
  // TABEL CUSTOMER //
    //route for homepage user
    app.get('/data', (req, res) => {
        let sql = "SELECT tgl, Nama, alamat,no_hp, costumer.Id_POM,jenis_pom,harga FROM costumer JOIN produk_pom on costumer.Id_POM = produk_pom.Id_POM";
        let query = conn.query(sql, (err, results) => {
          if (err) throw err;
          res.render('datacostumer', {
            results: results
          });
        });
      });

        // I N V O I C E //
    //route for homepage user
    app.get('/invoice', (req, res) => {
        let sql = "SELECT id_costumer, tgl, Nama, Alamat,no_hp, costumer.Id_POM,jenis_pom,harga FROM costumer JOIN produk_pom on costumer.Id_POM = produk_pom.Id_POM ORDER BY id_costumer DESC LIMIT 1";
        let query = conn.query(sql, (err, results) => {
          if (err) throw err;
          res.render('invoice', {
            results: results
          });
        });
      });

      app.get('/invoice_datacostumer', (req, res) => {
        let sql = "SELECT id_costumer, tgl, Nama, Alamat,no_hp, costumer.Id_POM,jenis_pom,harga FROM costumer JOIN produk_pom on costumer.Id_POM = produk_pom.Id_POM where id_costumer = '" + req.body.id_costumer + "'";
        let query = conn.query(sql, (err, results) => {
          if (err) throw err;
          res.render('invoice', {
            results: results
          });
        });
      });
    
    
app.use('/public', express.static(__dirname + '/public'));

//define Routes
app.use('/',require('./routes/pages'));
app.use('/auth', require('./routes/auth'));

app.listen(4000, () => {
    console.log("Success to access port 4000");
})