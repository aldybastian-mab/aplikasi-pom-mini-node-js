-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Des 2020 pada 08.32
-- Versi server: 10.4.6-MariaDB
-- Versi PHP: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pom`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `alat`
--

CREATE TABLE `alat` (
  `Id_Alat` int(20) NOT NULL,
  `lapisan_cat` varchar(100) NOT NULL,
  `alat_tangki` varchar(500) NOT NULL,
  `alat_mesin` varchar(500) NOT NULL,
  `bahan_instalasi` varchar(500) NOT NULL,
  `spesifikasi_mesin` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `alat`
--

INSERT INTO `alat` (`Id_Alat`, `lapisan_cat`, `alat_tangki`, `alat_mesin`, `bahan_instalasi`, `spesifikasi_mesin`) VALUES
(1, 'Expoxy. Cat Sintetis Putih, Clear', 'Plat Besi ketebalan 1,8mm, Las Tangki MMA, Cat 2 Lapis (Cat Sintetis Hitam dan Clear), Selang Swivel Panjang 4m, Nozzle TPG-HQ', 'Holder pompa (Pipa Galvanis ½ inch & Las MIG), Pipa galvanis ½ inch (Las menggunakan MIG), Terdapat 3 Pilihan Pompa (Full-Pump pertangki 3 unit, Water Pump model DAB 1 unit), Terdapat 2 Pilihan Alat Sensor (Water Flow Sensor & Assymeter SPBU)\r\n', 'Sistem Sirkulasi - Coupler Compressor - Napple - Vlogring ½ x ¾ inch - Elbow ¾ inch\r\n', 'CPU dan Display Bahan vr-4 Double Layer Import, Keypad Matrix 4x4, Power Supply 30w, Emergency Acu ns-40\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `costumer`
--

CREATE TABLE `costumer` (
  `id_costumer` int(11) NOT NULL,
  `tgl` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Nama` varchar(100) NOT NULL,
  `Alamat` text NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `Id_POM` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `costumer`
--

INSERT INTO `costumer` (`id_costumer`, `tgl`, `Nama`, `Alamat`, `no_hp`, `Id_POM`) VALUES
(1, '2020-12-20 19:07:26', 'Aldy Bastian', 'Alamat Kampus. Kampus Politeknik Negeri Lampung Terletak di Jalan Soekarno -Hatta No.10, Rajabasa, Bandar Lampung, Lampung Indonesia, 35141', '345678', 1),
(2, '2020-12-20 18:03:42', 'rahmat hardiyasah', 'ifhieafijewoif', '324723982478923', 2),
(3, '2020-12-20 18:04:15', 'aefhoiefa', 'afjiajaekjfkale', '73647236423', 3),
(4, '2020-12-20 18:04:15', 'jekfjwfskjfkls', 'awfmakeljfkaejalfk', '28429409', 1),
(5, '2020-12-20 21:45:30', 'efwfwe', 'wefwefwewf', '454353445', 1),
(6, '2020-12-20 21:45:48', 'fgwfwfwefwfwfewf', 'fwffewfewfewffffffffffffffffffffffffffffewfwefvwe', '543535236346', 2),
(7, '2020-12-20 21:46:09', 'gegregegergerg', 'dfggergvteegergergergergewrgrgergergerw', '3456435643', 3),
(8, '2020-12-20 21:46:25', 'etyvt34tv3t', 't3vtt34t43tv34t', '546565656', 3),
(9, '2020-12-20 21:46:39', 'rewtfggqr', 'rgggggggggggggggggggggggggggggv3gqqc4wc c', '4356436435643', 3),
(10, '2020-12-20 21:46:53', 'ertveertertvewtv', 'dgvtretgewrtvwdtvttr', '435435345435', 2),
(11, '2020-12-20 21:47:08', '2vr24cvr2rv2rv2r1vr3r', '23rv23r23v1rc213r23v32', '4354354325435', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk_pom`
--

CREATE TABLE `produk_pom` (
  `Id_POM` int(11) NOT NULL,
  `jenis_pom` varchar(20) NOT NULL,
  `harga` int(10) NOT NULL,
  `kapasitas_tangki` varchar(20) NOT NULL,
  `tinggi` varchar(7) NOT NULL,
  `lebar` varchar(7) NOT NULL,
  `panjang` varchar(7) NOT NULL,
  `tebal` varchar(7) NOT NULL,
  `plat` varchar(20) NOT NULL,
  `bahan_body` varchar(20) NOT NULL,
  `Id_Alat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `produk_pom`
--

INSERT INTO `produk_pom` (`Id_POM`, `jenis_pom`, `harga`, `kapasitas_tangki`, `tinggi`, `lebar`, `panjang`, `tebal`, `plat`, `bahan_body`, `Id_Alat`) VALUES
(1, 'Pom-Mini 1 Nozzle', 8000000, '120 Ltr / tangki', '180 cm', '45 cm', '65 cm', '1,2 mm', 'Galvanis Anti Karat', 'Kerangka Hollow', 1),
(2, 'Pom-Mini 2 Nozzle', 13000000, '80 Ltr / tangki', '180 cm', '45 cm', '80 cm', '1,2 mm', 'Galvanis Anti Karat', 'Kerangka Hollow', 1),
(3, 'Pom-Mini 3 Nozzle', 18000000, '70 Ltr / tangki', '180 cm', '45 cm', '95 cm', '1,2 mm', 'Galvanis Anti Karat', 'Kerangka Hollow', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(7, 'qwerty', 'bastian@gmail.com', '$2a$08$BYdF2/d4dNXWEj2YPlnCyeMcO2s1q9YCEFaxwrsS782KJ.9XZXa7i');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `alat`
--
ALTER TABLE `alat`
  ADD PRIMARY KEY (`Id_Alat`);

--
-- Indeks untuk tabel `costumer`
--
ALTER TABLE `costumer`
  ADD PRIMARY KEY (`id_costumer`),
  ADD KEY `Id_POM` (`Id_POM`);

--
-- Indeks untuk tabel `produk_pom`
--
ALTER TABLE `produk_pom`
  ADD PRIMARY KEY (`Id_POM`),
  ADD KEY `Id_Alat` (`Id_Alat`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `alat`
--
ALTER TABLE `alat`
  MODIFY `Id_Alat` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `costumer`
--
ALTER TABLE `costumer`
  MODIFY `id_costumer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `produk_pom`
--
ALTER TABLE `produk_pom`
  MODIFY `Id_POM` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `costumer`
--
ALTER TABLE `costumer`
  ADD CONSTRAINT `costumer_ibfk_1` FOREIGN KEY (`Id_POM`) REFERENCES `produk_pom` (`Id_POM`);

--
-- Ketidakleluasaan untuk tabel `produk_pom`
--
ALTER TABLE `produk_pom`
  ADD CONSTRAINT `produk_pom_ibfk_1` FOREIGN KEY (`Id_Alat`) REFERENCES `alat` (`Id_Alat`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
